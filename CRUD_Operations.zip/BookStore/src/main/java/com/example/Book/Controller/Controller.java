package com.example.Book.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Book.Entity.Book;
import com.example.Book.Service.BookService;

@RestController
public class Controller {

	@Autowired
	BookService bs;
	
	@GetMapping("/viewall")
	public List<Book> view()
	{
		return bs.getalldata();
	}
	@GetMapping("/viewbyid/{id}")
	public Book viewbyid(@PathVariable int id)
	{
		return bs.getBook(id);
	}
	
	@PostMapping("/add")
	public Book addentity(@RequestBody Book bk)
	{
		return bs.insertBook(bk);
	}
	@PutMapping("/update/{id}")
	public Book updateBook(@RequestBody Book bk, int id)
	{
		return bs.updateBook(bk, id);
	}
	@DeleteMapping("/delete/{id}")
	public String deleteBook(int id)
	{
		return bs.deleteBook(id);
	}
}

