package com.example.Book.Service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.example.Book.Entity.Book;


@Component
public interface BookService {
	String deleteBook(int id);
	
	Book insertBook(Book bk);
	Book updateBook(Book bk,int id);
	Book getBook(int id);
	
	
	List<Book> getalldata();
	
	
	
	
}
