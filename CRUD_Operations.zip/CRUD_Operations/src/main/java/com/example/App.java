package com.example;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import model.Batsman;
import model.Bowler;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Configuration cfg=new Configuration();
    	cfg=cfg.configure();
        System.out.println( "cfg is ready "+ cfg );
        
        SessionFactory sf=cfg.buildSessionFactory();
        System.out.println( "SessionFactory is ready "+ sf );
        Session s=sf.openSession();
        Batsman p1 = new Batsman();
        p1.setPlayer_name("faiz");
        p1.setPlayer_type("right hand batsman");
        p1.setPlayer_runs(100);
        p1.setPlayer_score(78);
        p1.setPlayer_age(25);
        p1.setPlayer_avg(12.56);
        
        
        Bowler p2 = new Bowler();
       p2.setPlayer_name("kashif");
       p2.setPlayer_age(21);
       p2.setPlayer_avg(19);
       p2.setPlayer_economy(5);
       p2.setPlayer_type("right hand bowler");
       p2.setPlayer_wickets(234);

     
       Transaction tr=s.beginTransaction();
       Batsman bd =s.load(Batsman.class, 14);
       s.save(p1);
       s.save(p2);
       s.delete(bd);
       tr.commit();
       s.close();
       System.out.println( "object saved......");
       
       
    }
}