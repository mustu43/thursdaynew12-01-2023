package model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "indianbatsman")
public class Batsman {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int player_id;
	private String player_name;
	private int player_age;
	private String player_type;
	private int player_score;
	private int player_runs;
	private double player_avg;
	public Batsman() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Batsman(int player_id, String player_name, int player_age, String player_type, int player_score,
			int player_runs, double player_avg) {
		super();
		this.player_id = player_id;
		this.player_name = player_name;
		this.player_age = player_age;
		this.player_type = player_type;
		this.player_score = player_score;
		this.player_runs = player_runs;
		this.player_avg = player_avg;
	}
	public int getPlayer_id() {
		return player_id;
	}
	public void setPlayer_id(int player_id) {
		this.player_id = player_id;
	}
	public String getPlayer_name() {
		return player_name;
	}
	public void setPlayer_name(String player_name) {
		this.player_name = player_name;
	}
	public int getPlayer_age() {
		return player_age;
	}
	public void setPlayer_age(int player_age) {
		this.player_age = player_age;
	}
	public String getPlayer_type() {
		return player_type;
	}
	public void setPlayer_type(String player_type) {
		this.player_type = player_type;
	}
	public int getPlayer_score() {
		return player_score;
	}
	public void setPlayer_score(int player_score) {
		this.player_score = player_score;
	}
	public int getPlayer_runs() {
		return player_runs;
	}
	public void setPlayer_runs(int player_runs) {
		this.player_runs = player_runs;
	}
	public double getPlayer_avg() {
		return player_avg;
	}
	public void setPlayer_avg(double player_avg) {
		this.player_avg = player_avg;
	}
	
	}
	


