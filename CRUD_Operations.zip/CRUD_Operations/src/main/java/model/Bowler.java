package model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Getter
@AllArgsConstructor
@Setter
@NoArgsConstructor
@ToString


@Entity
@Table(name = "indanbowler")
public class Bowler {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int player_id;
	private String player_name;
	private int player_age;
	private String player_type;
	private int player_wickets;
	private int player_economy;
	private double player_avg;

}
